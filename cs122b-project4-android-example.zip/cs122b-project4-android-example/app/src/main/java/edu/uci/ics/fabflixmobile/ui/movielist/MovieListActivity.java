package edu.uci.ics.fabflixmobile.ui.movielist;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import edu.uci.ics.fabflixmobile.R;
import edu.uci.ics.fabflixmobile.data.NetworkManager;
import edu.uci.ics.fabflixmobile.data.model.Movie;
import edu.uci.ics.fabflixmobile.ui.login.LoginActivity;
import edu.uci.ics.fabflixmobile.ui.singlemovie.SingleMovieActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MovieListActivity extends AppCompatActivity {

    private final String host = "10.0.2.2";
    private final String port = "8080";
    private final String domain = "cs122b_project1_api_example_war";
    private final String baseURL = "http://" + host + ":" + port + "/" + domain;

    private RequestQueue queue;
    private ListView movieList;
    private Button prevButton;
    private Button nextButton;
    private TextView pageNumber;
    private String query;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movielist);
        movieList = findViewById(R.id.list);
        prevButton = findViewById(R.id.prevButton);
        nextButton = findViewById(R.id.nextButton);

        // TODO: this should be retrieved from the backend server
        queue = NetworkManager.sharedManager(this).queue;
        Intent searchIntent = getIntent();
        query = searchIntent.getStringExtra("title");
        getMovies();
    }

    @SuppressLint("SetTextI18n")
    public void getMovies() {
        final JsonArrayRequest loginRequest = new JsonArrayRequest(
                Request.Method.GET,
                baseURL + "/api/movies?title=" + query,
                null,
                response -> {
                    // Parse the JSON response to retrieve movie data
                    ArrayList<Movie> movies = parseMovies(response);

                    // Display movies in the ListView
                    displayMovies(movies);
                },
                error -> {
                    // error
                    Log.d("movie.error", error.toString());
                }) {
        };
        // important: queue.add is where the login request is actually sent
        queue.add(loginRequest);
    }
    private ArrayList<Movie> parseMovies(JSONArray jsonArray) {
        ArrayList<Movie> movies = new ArrayList<>();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String id = jsonObject.getString("movie_id");
                String title = jsonObject.getString("movie_title");
                int year = jsonObject.getInt("movie_year");
                String director = jsonObject.getString("movie_director");
                String genres = jsonObject.getString("movie_genres");
                String stars = jsonObject.getString("movie_stars");

                // Add a new Movie object to the ArrayList
                movies.add(new Movie(id, title, (short) year, director, genres, stars));
            }
        } catch (JSONException e) {
            Log.e("parse.error", e.toString());
        }
        return movies;
    }

    private void displayMovies(ArrayList<Movie> movies) {
        // Display movies in the ListView using the custom adapter
        MovieListViewAdapter adapter = new MovieListViewAdapter(this, movies);
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Movie movie = movies.get(position);
            Intent singleMovieIntent = new Intent(this, SingleMovieActivity.class);
            singleMovieIntent.putExtra("id", movie.getId()); // Assuming getId() returns the movie ID
            startActivity(singleMovieIntent);
        });
    }

    public static String cleanString(String input) {
        // Remove square brackets and quotes
        String cleaned = input.replaceAll("[\\[\\]\"]", "");

        // Split the cleaned string by commas
        String[] parts = cleaned.split(", ");

        // Extract only the names (even indices in the array)
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < parts.length; i += 2) {
            result.append(parts[i]);
            if (i < parts.length - 2) {
                result.append(", ");
            }
        }

        return result.toString();
    }
}
