package edu.uci.ics.fabflixmobile.ui.mainpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import edu.uci.ics.fabflixmobile.R;
import edu.uci.ics.fabflixmobile.ui.movielist.MovieListActivity;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);

        TextView mainTextView = findViewById(R.id.mainTextView);
        searchEditText = findViewById(R.id.searchEditText);
        Button searchButton = findViewById(R.id.searchButton);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performSearch();
            }
        });
    }

    private void performSearch() {
        String searchQuery = searchEditText.getText().toString().trim();

        // Pass the search query to the next activity (replace NextActivity.class with your actual activity)
        Intent intent = new Intent(this, MovieListActivity.class);
        intent.putExtra("title", searchQuery);
        startActivity(intent);
    }
}

