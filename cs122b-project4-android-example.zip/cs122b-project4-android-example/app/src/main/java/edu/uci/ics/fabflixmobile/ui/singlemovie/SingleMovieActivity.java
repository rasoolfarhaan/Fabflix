package edu.uci.ics.fabflixmobile.ui.singlemovie;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import edu.uci.ics.fabflixmobile.R;
import edu.uci.ics.fabflixmobile.data.NetworkManager;
import edu.uci.ics.fabflixmobile.data.model.Movie;
import edu.uci.ics.fabflixmobile.ui.login.LoginActivity;
import edu.uci.ics.fabflixmobile.ui.movielist.MovieListViewAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SingleMovieActivity extends AppCompatActivity {

    private final String host = "10.0.2.2";
    private final String port = "8080";
    private final String domain = "cs122b_project1_api_example_war";
    private final String baseURL = "http://" + host + ":" + port + "/" + domain;

    private RequestQueue queue;

    private String id;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movielist);

        queue = NetworkManager.sharedManager(this).queue;
        Intent searchIntent = getIntent();
        id = searchIntent.getStringExtra("id");
        getSingleMovie();
    }

    @SuppressLint("SetTextI18n")
    public void getSingleMovie() {
        final JsonArrayRequest singleMovieRequest = new JsonArrayRequest(
                Request.Method.GET,
                baseURL + "/api/single-movie?id=" + id,
                null,
                response -> {
                    try {
                        System.out.println(response);
                        JSONObject movieObject = response.getJSONObject(0);
                        String title = movieObject.getString("movie_title");
                        int year = movieObject.getInt("movie_year");
                        String director = movieObject.getString("movie_director");
                        String genres = movieObject.getString("movie_genres");
                        String stars = movieObject.getString("movie_stars");
                        String rating = movieObject.getString("movie_rating");
                        System.out.println(title + "..." + year + "..." + director  + "..." + genres + "..." + stars  + "..." + rating);
                        ArrayList<Movie> movies = new ArrayList<>();
                        movies.add(new Movie("", title, (short)year, director, genres, stars));
                        displayMovies(movies);

                    } catch (JSONException e) {
                        Log.e("parse.error", e.toString());
                    }

                },
                error -> {
                    // Handle error
                    Log.d("movie.error", error.toString());
                });

        // Important: queue.add is where the request is actually sent
        queue.add(singleMovieRequest);
    }

    private ArrayList<Movie> parseMovies(JSONArray jsonArray) {
        ArrayList<Movie> movies = new ArrayList<>();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String id = jsonObject.getString("movie_id");
                String title = jsonObject.getString("movie_title");
                int year = jsonObject.getInt("movie_year");
                String director = jsonObject.getString("movie_director");
                String genres = jsonObject.getString("movie_genres");
                String stars = jsonObject.getString("movie_stars");

                // Add a new Movie object to the ArrayList
                movies.add(new Movie(id, title, (short) year, director, genres, stars));
            }
        } catch (JSONException e) {
            Log.e("parse.error", e.toString());
        }
        return movies;
    }

    private void displayMovies(ArrayList<Movie> movies) {
        // Display movies in the ListView using the custom adapter
        MovieListViewAdapter adapter = new MovieListViewAdapter(this, movies);
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
